-- NUOVI SURROGATI
insert into lookup_dt_scontrino (codScontrino)
select s.codScontrino
from scontrino s
where s.codScontrino not in (
    select l.codScontrino
    from lookup_dt_scontrino l
);

-- NUOVE TUPLE
insert into dt_scontrino (idScontrino, codScontrino, data, importo, codRistorante, nome, città)
select s.codScontrino, s.data, s.importo, s.codRistorante, r.nome, r.città
from scontrino s
    join ristorante r on (s.codRistorante = r.codRistorante)
    join lookup_dt_scontrino l on (s.codScontrino = l.codScontrino)
where l.codScontrino not in (
    select dt.idScontrino
    from dt_scontrino dt
);